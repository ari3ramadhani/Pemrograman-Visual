﻿Imports MySql.Data.MySqlClient
Public Class Form1
    Dim koneksi As MySqlConnection
    Dim adapter As MySqlDataAdapter 'nampilin data di data gridview
    Dim cari, start As String
    Sub konek()
        start = "server=localhost;user id=root;password=; database=mahasiswa"
        koneksi = New MySqlConnection(start)
        koneksi.Open()
    End Sub
    Sub table()
        adapter = New MySqlDataAdapter("select * from mhs", koneksi)
        Dim table As New DataTable
        adapter.Fill(table)
        DataGridView1.DataSource = table
    End Sub
    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Call konek()
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        table()
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click, Button3.Click
        Dim com As New MySqlCommand("insert into mhs(id,nim,nama,fakultas,jurusan,status,tanggal_masuk) values (NULL,'" &
                                        TextBox2.Text & "', '" & TextBox3.Text & "', '" &
                                        TextBox4.Text & "', '" & TextBox5.Text & "', '" &
                                        TextBox6.Text & "', '" & Format(DateTimePicker1.Value, "yyyy-MM-dd") & "')", koneksi)
        com.ExecuteNonQuery()
        MsgBox("Data berhasil diinput")
        table()
    End Sub

    Private Sub TextBox1_TextChanged(sender As System.Object, e As System.EventArgs) Handles TextBox1.TextChanged
        cari = TextBox1.Text
        Dim adapter As New MySqlDataAdapter("select * from mhs where nama like '%" & cari &
                                            "%' or nim like'%" & cari &
                                            "%'", koneksi)
        Dim table As New DataTable
        adapter.Fill(table)
        DataGridView1.DataSource = table
    End Sub

    Private Sub TextBox5_TextChanged(sender As System.Object, e As System.EventArgs) Handles TextBox5.TextChanged, TextBox6.TextChanged

    End Sub

    Private Sub Label4_Click(sender As System.Object, e As System.EventArgs) Handles Label4.Click, Label5.Click, Label6.Click

    End Sub

    Private Sub TextBox4_TextChanged(sender As System.Object, e As System.EventArgs) Handles TextBox4.TextChanged

    End Sub

    Private Sub Label3_Click(sender As System.Object, e As System.EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label2_Click(sender As System.Object, e As System.EventArgs) Handles Label2.Click

    End Sub

    Private Sub TextBox3_TextChanged(sender As System.Object, e As System.EventArgs) Handles TextBox3.TextChanged

    End Sub
End Class